sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sap.btp.sampleapp.controller.App", {
        onInit() {
        }
      });
    }
  );
  